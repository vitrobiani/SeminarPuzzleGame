# System Architecture Diagram

## 🏗️ Component Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER'S DESKTOP                           │
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │                    SERVER (server.py)                     │ │
│  │                      [SINGLETON]                          │ │
│  │  ┌─────────────────────────────────────────────────────┐ │ │
│  │  │              Server GUI (tkinter)                   │ │ │
│  │  │  ┌─────────────────┐  ┌─────────────────────────┐  │ │ │
│  │  │  │Launch Human Btn │  │Launch Computer Btn      │  │ │ │
│  │  │  └────────┬────────┘  └────────┬────────────────┘  │ │ │
│  │  │           │                     │                   │ │ │
│  │  │  ┌────────▼─────────────────────▼────────────────┐ │ │ │
│  │  │  │         Server Log Display                    │ │ │ │
│  │  │  │  [Activity Logging & Client Monitoring]       │ │ │ │
│  │  │  └───────────────────────────────────────────────┘ │ │ │
│  │  └─────────────────────────────────────────────────────┘ │ │
│  │                                                           │ │
│  │  ┌─────────────────────────────────────────────────────┐ │ │
│  │  │         Network Layer (Socket Server)               │ │ │
│  │  │         Port: 5000, Protocol: TCP/IP                │ │ │
│  │  │         Threading: One thread per client            │ │ │
│  │  └───────────┬─────────────────────────┬───────────────┘ │ │
│  └──────────────┼─────────────────────────┼─────────────────┘ │
│                 │                         │                   │
│    ┌────────────▼──────────┐   ┌─────────▼──────────────┐   │
│    │  HUMAN CLIENT(S)      │   │  COMPUTER CLIENT       │   │
│    │  (human_client.py)    │   │  (computer_client.py)  │   │
│    │  [Multiple instances] │   │  [SINGLETON - 1 only]  │   │
│    └───────────────────────┘   └────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📊 MVC Architecture - Human Player

```
┌────────────────────────────────────────────────────────────────┐
│                    HUMAN PLAYER CLIENT                         │
│                                                                │
│  ┌──────────────────────────────────────────────────────────┐ │
│  │              CONTROLLER (human_player_controller.py)     │ │
│  │              • Game logic coordination                   │ │
│  │              • Network communication                     │ │
│  │              • Statistics management                     │ │
│  │              • Memento coordination                      │ │
│  └────┬─────────────────────────────────────────────┬───────┘ │
│       │                                             │         │
│       │                                             │         │
│  ┌────▼────────────────────┐          ┌────────────▼──────┐  │
│  │  MODEL                  │          │  VIEW             │  │
│  │  (puzzle_model.py)      │          │  (human_player_   │  │
│  │                         │          │   view.py)        │  │
│  │  • Board state          │          │                   │  │
│  │  • Move logic           │◄────────►│  • tkinter GUI    │  │
│  │  • Solvability check    │          │  • Tile buttons   │  │
│  │  • Puzzle generation    │          │  • Controls       │  │
│  └─────────────────────────┘          │  • Timer display  │  │
│                                        └───────────────────┘  │
│  ┌──────────────────────────────────────────────────────────┐ │
│  │         SUPPORTING COMPONENTS                            │ │
│  │  ┌────────────────┐  ┌────────────────┐  ┌────────────┐ │ │
│  │  │ Memento        │  │ Statistics     │  │ Network    │ │ │
│  │  │ (memento.py)   │  │ (statistics.py)│  │ (socket)   │ │ │
│  │  │                │  │                │  │            │ │ │
│  │  │ • Undo stack   │  │ • Game stats   │  │ • Server   │ │ │
│  │  │ • Redo stack   │  │ • Persistence  │  │   connection│ │ │
│  │  │ • State saves  │  │ • Reports      │  │ • Logging  │ │ │
│  │  └────────────────┘  └────────────────┘  └────────────┘ │ │
│  └──────────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────┘
```

---

## 🤖 MVC Architecture - Computer Player

```
┌────────────────────────────────────────────────────────────────┐
│                   COMPUTER PLAYER CLIENT                       │
│                                                                │
│  ┌──────────────────────────────────────────────────────────┐ │
│  │           CONTROLLER (computer_player_controller.py)     │ │
│  │           • AI solving coordination                      │ │
│  │           • Network communication                        │ │
│  │           • Solution execution                           │ │
│  │           • Animation control                            │ │
│  └────┬─────────────────────────────────────────────┬───────┘ │
│       │                                             │         │
│       │                                             │         │
│  ┌────▼────────────────────┐          ┌────────────▼──────┐  │
│  │  MODEL                  │          │  VIEW             │  │
│  │  (puzzle_model.py)      │          │  (computer_player_│  │
│  │                         │          │   view.py)        │  │
│  │  • Board state          │          │                   │  │
│  │  • Move execution       │◄────────►│  • tkinter GUI    │  │
│  │  • Solvability check    │          │  • Tile display   │  │
│  │  • Puzzle generation    │          │  • Status info    │  │
│  └─────────────────────────┘          │  • Progress bar   │  │
│                                        └───────────────────┘  │
│  ┌──────────────────────────────────────────────────────────┐ │
│  │              SOLVER COMPONENT                            │ │
│  │  ┌────────────────────────────────────────────────────┐  │ │
│  │  │           A* Solver (astar_solver.py)             │  │ │
│  │  │                                                    │  │ │
│  │  │  • Priority queue (heapq)                         │  │ │
│  │  │  • Manhattan distance heuristic                   │  │ │
│  │  │  • State space search                             │  │ │
│  │  │  • Path reconstruction                            │  │ │
│  │  │  • 120-second timeout                             │  │ │
│  │  └────────────────────────────────────────────────────┘  │ │
│  └──────────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Data Flow Diagram

### Human Player - Making a Move

```
User Click on Tile
       │
       ▼
┌──────────────────┐
│  VIEW            │  Detects click event
│  tile_button     │  Gets (row, col)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  CONTROLLER      │  handle_tile_click(row, col)
│  validates move  │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  MODEL           │  move(tile_pos)
│  updates board   │  Returns True/False
│  state           │
└────────┬─────────┘
         │ (if valid)
         ▼
┌──────────────────┐
│  MEMENTO         │  save_state()
│  stores state    │  Adds to undo stack
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  CONTROLLER      │  Updates view
│  checks if       │  Checks if solved
│  solved          │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  VIEW            │  update_board()
│  refreshes       │  update_move_count()
│  display         │  Shows new state
└──────────────────┘
```

### Computer Player - Solving

```
User Clicks "New Game & Solve"
       │
       ▼
┌──────────────────┐
│  CONTROLLER      │  start_new_game_and_solve()
│  generates       │  Creates new puzzle
│  puzzle          │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  MODEL           │  is_solvable()
│  checks if       │  Returns True/False
│  solvable        │
└────────┬─────────┘
         │ (if solvable)
         ▼
┌──────────────────┐
│  CONTROLLER      │  Starts solver thread
│  spawns thread   │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  A* SOLVER       │  solve()
│  runs in         │  Uses priority queue
│  separate        │  Manhattan heuristic
│  thread          │  Returns move list
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  CONTROLLER      │  _execute_solution()
│  executes        │  Animates moves
│  moves           │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  MODEL           │  move() for each step
│  updates board   │
│  state           │
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│  VIEW            │  update_board()
│  animates        │  Shows progress
│  solution        │
└──────────────────┘
```

---

## 🌐 Network Communication Flow

```
┌─────────────────────────────────────────────────────────┐
│                     SERVER PROCESS                      │
│                                                         │
│  Main Thread                                            │
│  ├─ GUI Event Loop (tkinter)                           │
│  │                                                      │
│  Accept Thread                                          │
│  ├─ Listens on port 5000                               │
│  └─ Spawns handler threads                             │
│                                                         │
│  Client Handler Thread 1                                │
│  ├─ Receives from Client 1                             │
│  └─ Logs messages                                       │
│                                                         │
│  Client Handler Thread 2                                │
│  ├─ Receives from Client 2                             │
│  └─ Logs messages                                       │
└─────────────────────────────────────────────────────────┘
         ▲                              ▲
         │                              │
         │ TCP/IP                       │ TCP/IP
         │ Pickle Protocol              │ Pickle Protocol
         │                              │
         │                              │
┌────────▼──────────┐          ┌────────▼──────────┐
│  HUMAN CLIENT 1   │          │  COMPUTER CLIENT  │
│                   │          │                   │
│  Main Thread      │          │  Main Thread      │
│  ├─ GUI Loop      │          │  ├─ GUI Loop      │
│  └─ Network I/O   │          │  └─ Network I/O   │
│                   │          │                   │
│                   │          │  Solver Thread    │
│                   │          │  └─ A* Algorithm  │
└───────────────────┘          └───────────────────┘
```

---

## 🎯 Design Pattern Implementation

### 1. MVC Pattern
```
Model (puzzle_model.py)
  ↓ data
Controller (human_player_controller.py)
  ↓ updates
View (human_player_view.py)
  ↑ user events
Controller
```

### 2. Singleton Pattern
```
Server Class:
  __new__() → checks _instance
           → if None: create
           → if exists: return existing
           
Computer Client:
  Only one window allowed
  Server enforces: computer_client_active flag
```

### 3. Memento Pattern
```
Originator (PuzzleModel)
  ↓ creates
Memento (PuzzleMemento)
  ↓ stored in
Caretaker (PuzzleCaretaker)
  ↓ manages
Undo/Redo Stacks
```

---

## 📦 Module Dependencies

```
server.py
  ├─ tkinter (GUI)
  ├─ socket (networking)
  ├─ threading (concurrency)
  ├─ subprocess (client launching)
  └─ pickle (serialization)

human_client.py
  └─ human_player_controller.py
       ├─ puzzle_model.py
       ├─ human_player_view.py
       │    └─ tkinter
       ├─ memento.py
       ├─ statistics.py
       └─ socket, threading, pickle

computer_client.py
  └─ computer_player_controller.py
       ├─ puzzle_model.py
       ├─ computer_player_view.py
       │    └─ tkinter
       ├─ astar_solver.py
       │    └─ heapq (priority queue)
       └─ socket, threading, pickle
```

---

## 🔄 State Transitions

### Human Player Game States
```
[New Game]
    ↓
[Generating Puzzle]
    ↓
[Checking Solvability] ─→ [Unsolvable] → [Show Error]
    ↓
[Playing]
    ├─ [Make Move] → [Update Board] → [Check If Solved]
    ├─ [Undo] → [Restore Previous State]
    ├─ [Redo] → [Restore Next State]
    └─ [Resize] → [New Game]
    ↓
[Solved] → [Update Statistics] → [Show Report]
```

### Computer Player States
```
[Idle]
    ↓
[New Game & Solve]
    ↓
[Generating Puzzle]
    ↓
[Checking Solvability] ─→ [Unsolvable] → [Generate New]
    ↓
[Solving with A*]
    ├─ [Expanding Nodes]
    ├─ [Computing Heuristic]
    └─ [Timeout?] → [Show Error]
    ↓
[Solution Found]
    ↓
[Executing Moves] → [Animate Each Step]
    ↓
[Solved] → [Show Statistics]
```

---

## 📈 Performance Characteristics

### Solvability Check
- **Time Complexity**: O(n²) where n = board dimension
- **Space Complexity**: O(1)
- **Method**: Inversion counting

### A* Solver
- **Time Complexity**: O(b^d) worst case, where b = branching factor, d = depth
- **Space Complexity**: O(b^d) for storing states
- **Optimality**: Yes (Manhattan distance is admissible)
- **Completeness**: Yes (with timeout protection)

### Typical Solving Times (on modern PC):
- 3×3: < 1 second
- 4×4: 1-10 seconds
- 5×5: 10-60 seconds
- 6×6: 30-120 seconds (may timeout)

---

This architecture ensures:
✅ Clean separation of concerns  
✅ Maintainable codebase  
✅ Scalable design  
✅ Thread-safe operations  
✅ Efficient algorithms  
✅ User-friendly interface  
